﻿define(function (require) {

    return function (targetTotal,callback) {

        var self = this;

        self.setTwoDecimalPlaces = function (input) {
            var value = input.toString();
            var decimalPlace = value.indexOf('.');
            if (decimalPlace < 0) {
                value += '.00'
            } else if (decimalPlace == value.length - 1) {
                value += '00';
            } else if (decimalPlace == value.length - 2) {
                value += '0';
            } else if (decimalPlace == value.length - 3) {
                ;
            } else {
                value = value.slice(0, decimalPlace) + '.' + value.slice(decimalPlace + 1, decimalPlace + 3);
            }

            return value;
        }

        self.canAddItem = false;
        self.tendered = 0;
        self.manualMode = false;
        self.wantManualDecimal = false;
        var currentManualValue = '';
        self.exactTarget = self.setTwoDecimalPlaces(ko.computed(targetTotal)());
        if (self.exactTarget >= 0) {
            self.closestDollarTarget = Math.ceil(self.exactTarget);
            self.closestBillTarget = self.closestDollarTarget;
            while (self.closestBillTarget % 5 != 0) {
                self.closestBillTarget += 1;
            }
        }
        else {
            self.exactTarget = 0;
            self.closestDollarTarget = 0;
            self.closestBillTarget = 0;
        }
        
        self.updateTendered=function(newValue) {
            self.tendered = Math.abs(parseFloat(newValue));
            document.getElementById("tendered").value = self.setTwoDecimalPlaces(self.tendered);
            self.canAddItem = self.tendered >= 0.01;
            self.manualMode = false;
        }
        
        self.addToTendered = function (amount) {
            self.processManual();
            self.updateTendered(self.tendered + amount);
        }

        self.moveDecimalRight = function () {
            var calculatedString = document.getElementById("tendered").value.toString();
            var decimalPlace = calculatedString.indexOf('.');
            if (decimalPlace < 0) {
                calculatedString += '0';
            } else {
                if (decimalPlace == calculatedString.length - 1) {
                    calculatedString = calculatedString.replace('.', '');
                    calculatedString += '0';
                } else {
                    var temp = calculatedString.slice(0, decimalPlace)+calculatedString.slice(decimalPlace + 1, decimalPlace+2)+'.';
                    if (temp.length==calculatedString.length) {
                        calculatedString = temp.replace('.', '');
                    } else {
                        calculatedString = temp + calculatedString.slice(decimalPlace + 2, calculatedString.length);
                    }
                }
            }
            self.processManual();
            self.updateTendered(calculatedString);
        }
        self.moveDecimalLeft = function () {
            var input = parseFloat(document.getElementById("tendered").value);
            var calculatedString = self.setTwoDecimalPlaces(Math.floor(self.setTwoDecimalPlaces(input) * 10) / 100);
            self.processManual();
            self.updateTendered(calculatedString);
        }

        self.updateManual = function (input) {
            if (self.manualMode == false) {
                self.manualMode = true;
                document.getElementById("tendered").setAttribute('type', 'text');
                currentManualValue = "";
            }
            if (input == '.') {
                self.setWantDecimal(!self.wantManualDecimal);
                return;
            } else if (self.wantManualDecimal == true) {
                currentManualValue = currentManualValue.replace('.', '');
                currentManualValue += '.';
                self.setWantDecimal(false);
            }

            currentManualValue += input;
            document.getElementById("tendered").value = currentManualValue;
            self.canAddItem = parseFloat(currentManualValue)>=.01;
        }

        self.setWantDecimal=function(which) {
            self.wantManualDecimal = which;
            if (which == true) {
                document.getElementById('manualDecimal').style.backgroundColor='darkgray';
            } else {
                document.getElementById('manualDecimal').style.backgroundColor = '';
            }
        }

        self.processManual = function () {
            self.setWantDecimal(false);
            document.getElementById("tendered").setAttribute('type', 'number');
            if (self.manualMode == true) {
                currentManualValue = '';
                self.updateTendered(document.getElementById("tendered").value);
            }
        }

        self.checkCanAdd = function () {
            self.canAddItem = (self.tendered >= 0.01 || parseFloat(currentManualValue) >= .01 || parseFloat(self.setTwoDecimalPlaces(document.getElementById('tendered').value)) >=0.01);
        }

        self.cancel = function () {
            close();
        };

        self.addItem = function () {
            self.processManual();
            var item = {
                description: 'Cash payment',
                quantity:1,
                price: -self.tendered
            };

            close(item);
        };

        function close() {

            if (callback) {
                callback.apply(self, arguments);
            }
        }
    };
});
﻿define(function (require) {
    var dialog = require('plugins/dialog');

    return function (parent) {

        var self = this;

        calculateTotal = function (parent) {
            //Coin calculations
            var pennyTotal = (parseInt(document.getElementById('penniesQuantity').value) + parseInt((document.getElementById('penniesRolls').value * 50))) * .01 || 0;
            document.getElementById('penniesTotal').value = parseFloat(pennyTotal).toFixed(2);
            var nickelTotal = (parseInt(document.getElementById('nickelsQuantity').value) + parseInt((document.getElementById('nickelsRolls').value * 40))) * .05 || 0;
            document.getElementById('nickelsTotal').value = parseFloat(nickelTotal).toFixed(2);
            var dimeTotal = (parseInt(document.getElementById('dimesQuantity').value) + parseInt((document.getElementById('dimesRolls').value * 50))) * .10 || 0;
            document.getElementById('dimesTotal').value = parseFloat(dimeTotal).toFixed(2);
            var quarterTotal = (parseInt(document.getElementById('quartersQuantity').value) + parseInt((document.getElementById('quartersRolls').value * 40))) * .25 || 0;
            document.getElementById('quartersTotal').value = parseFloat(quarterTotal).toFixed(2);
            var halfdollarTotal = parseInt(document.getElementById('halfdollarsQuantity').value) * .50 || 0;
            document.getElementById('halfdollarsTotal').value = parseFloat(halfdollarTotal).toFixed(2);
            var dollarcoinTotal = parseInt(document.getElementById('dollarcoinsQuantity').value) * 1.00 || 0;
            document.getElementById('dollarcoinsTotal').value = parseFloat(dollarcoinTotal).toFixed(2);
            //Cash calculations
            var oneTotal = parseInt(document.getElementById('onesQuantity').value) * 1.00 || 0;
            document.getElementById('onesTotal').value = parseFloat(oneTotal).toFixed(2);
            var twoTotal = parseInt(document.getElementById('twosQuantity').value) * 2.00 || 0;
            document.getElementById('twosTotal').value = parseFloat(twoTotal).toFixed(2);
            var fiveTotal = parseInt(document.getElementById('fivesQuantity').value) * 5.00 || 0;
            document.getElementById('fivesTotal').value = parseFloat(fiveTotal).toFixed(2);
            var tenTotal = parseInt(document.getElementById('tensQuantity').value) * 10.00 || 0;
            document.getElementById('tensTotal').value = parseFloat(tenTotal).toFixed(2);
            var twentyTotal = parseInt(document.getElementById('twentiesQuantity').value) * 20.00 || 0;
            document.getElementById('twentiesTotal').value = parseFloat(twentyTotal).toFixed(2);
            var fiftyTotal = parseInt(document.getElementById('fiftiesQuantity').value) * 50.00 || 0;
            document.getElementById('fiftiesTotal').value = parseFloat(fiftyTotal).toFixed(2);
            var hundredTotal = parseInt(document.getElementById('hundredsQuantity').value) * 100.00 || 0;
            document.getElementById('hundredsTotal').value = parseFloat(hundredTotal).toFixed(2);
            //Total calculations
            var grandTotal = pennyTotal + nickelTotal + dimeTotal + quarterTotal + halfdollarTotal + dollarcoinTotal + oneTotal + twoTotal + fiveTotal + tenTotal + twentyTotal + fiftyTotal + hundredTotal;
            document.getElementById("grandTotal").value = parseFloat(grandTotal).toFixed(2);
        }

        self.setAsOpeningTotal = function () {
            document.getElementById("openingBalance").value = document.getElementById("grandTotal").value;
            self.save();
            self.deactivate();
        }

        self.save = function () {
            parent.latestCounts['penniesQuantity'] = parseInt(document.getElementById('penniesQuantity').value);
            parent.latestCounts['penniesRolls'] = parseInt(document.getElementById('penniesRolls').value);
            parent.latestCounts['nickelsQuantity'] = parseInt(document.getElementById('nickelsQuantity').value);
            parent.latestCounts['nickelsRolls'] = parseInt(document.getElementById('nickelsRolls').value);
            parent.latestCounts['dimesQuantity'] = parseInt(document.getElementById('dimesQuantity').value);
            parent.latestCounts['dimesRolls'] = parseInt(document.getElementById('dimesRolls').value);
            parent.latestCounts['quartersQuantity'] = parseInt(document.getElementById('quartersQuantity').value);
            parent.latestCounts['quartersRolls'] = parseInt(document.getElementById('quartersRolls').value);
            parent.latestCounts['halfdollarsQuantity'] = parseInt(document.getElementById('halfdollarsQuantity').value);
            parent.latestCounts['dollarcoinsQuantity'] = parseInt(document.getElementById('dollarcoinsQuantity').value);
            parent.latestCounts['onesQuantity'] = parseInt(document.getElementById('onesQuantity').value);
            parent.latestCounts['twosQuantity'] = parseInt(document.getElementById('twosQuantity').value);
            parent.latestCounts['fivesQuantity'] = parseInt(document.getElementById('fivesQuantity').value);
            parent.latestCounts['tensQuantity'] = parseInt(document.getElementById('tensQuantity').value);
            parent.latestCounts['twentiesQuantity'] = parseInt(document.getElementById('twentiesQuantity').value);
            parent.latestCounts['fiftiesQuantity'] = parseInt(document.getElementById('fiftiesQuantity').value);
            parent.latestCounts['hundredsQuantity'] = parseInt(document.getElementById('hundredsQuantity').value);
        }

        self.deactivate = function () {
            self.close();
        }

        self.close = function () {
            dialog.close(self, self.digest);
        }

        self.clear = function () {
            var elements = document.getElementsByTagName('input');

            for (var i = 0; i < elements.length; i++) {
                if (elements[i].id.includes("Quantity") || elements[i].id.includes("Rolls")) {
                    elements[i].value = 0;
                }
            }

            calculateTotal();
        }

        self.setTDAttributes = function () {
            var elements = document.getElementsByTagName('input');

            for (var i = 0; i < elements.length; i++) {
                if (elements[i].id.includes("Quantity") || elements[i].id.includes("Rolls")) {
                    elements[i].setAttribute("placeholder", "0");
                    elements[i].setAttribute("type", "number");
                    elements[i].setAttribute("step", "1");
                    elements[i].setAttribute("min", "0");
                    elements[i].setAttribute("onchange", "value=parseFloat($(this).val()).toFixed(0);");
                    elements[i].setAttribute("data-bind", "event: {input: calculateTotal, click: calculateTotal, blur:calculateTotal}");
                    elements[i].setAttribute("class", "form-control");
                    elements[i].style = "width:75%";
                    ko.applyBindings(this, elements[i]);
                }
                else if (elements[i].id.includes("Total")) {
                    elements[i].setAttribute("type", "number");
                    elements[i].setAttribute("placeholder", "0.00");
                    elements[i].setAttribute("value", "0.00");
                    elements[i].setAttribute("step", "0.01");
                    elements[i].setAttribute("class", "form-control");
                    elements[i].readOnly = true;
                    ko.applyBindings(this, elements[i]);
                }
            }

            for (var key in parent.latestCounts) {
                if (document.getElementById(key)) {
                    document.getElementById(key).value = parent.latestCounts[key] || 0;
                }
                calculateTotal();
            }
        }

        return self;
    }
});